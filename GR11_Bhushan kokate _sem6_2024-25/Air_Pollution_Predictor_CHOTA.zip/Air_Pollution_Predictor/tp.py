import pandas as pd
import os

# Use a relative path for the CSV file
csv_path = os.path.join('data', 'location_detection.csv')
aqi_data = pd.read_csv(csv_path)
print(aqi_data.head())
